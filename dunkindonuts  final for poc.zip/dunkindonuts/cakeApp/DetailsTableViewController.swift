//
//  File.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 10/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit
class DetailsTableViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{

    
    
    
    
    /* Tableview datasource and delegate methods */
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "details", for: indexPath)
        return cell
    }
    
    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return ["hai","hello","hola","bonjour","vanakkam"]
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 50
    }
    
    
    
}
