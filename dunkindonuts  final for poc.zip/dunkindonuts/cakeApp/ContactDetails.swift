//
//  contactDetails.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 11/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import UIKit

class ContactDetails:UIViewController{
    
    
    @IBOutlet weak var name: UILabel!
    
    
    @IBOutlet weak var empId: UILabel!
    
    @IBOutlet weak var dob: UILabel!
    
    @IBOutlet weak var registered: UILabel!
   
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var emergencycontacts: UILabel!
    
    @IBOutlet weak var email1: UILabel!
    
    
    @IBOutlet weak var email2: UILabel!
    
    @IBOutlet weak var phone1: UILabel!
    
    @IBOutlet weak var phone2: UILabel!
    
    
    let dateFormatter = DateFormatter()
    
    
    override func viewDidLoad() {
        print("func overided")
        fetchContacts(data: JsonHelper.jsonData!)
    }

    func fetchContacts(data:NSData){
        
        
        do{
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            let jsonRootObjectDetails = try JSONSerialization.jsonObject(with: data as Data, options: [])
            let jsonDictionary = jsonRootObjectDetails as! [String:Any]
           
            
            let  personDic = jsonDictionary["person"] as! [String:Any]
             name.text = ((personDic["name"] as! String?)!)
            empId.text="Emp id  : \((personDic["empid"])!)"
           let birthdate = dateFormatter.date(from:(personDic["dateOfBirth"] as! String?)!)
            
            dob.text = "Dob : \(birthdate!)"
            //registered.text = "\((personDic["registered"])!)"
            phone.text = "\(jsonDictionary["product"]!)"
            
            let trainingDate = dateFormatter.date(from:jsonDictionary["trainingStartDate"] as! String)
            
            
            email.text = "Training Start Date :  \(trainingDate!)"
            
            let trainingEndDate = dateFormatter.date(from:(jsonDictionary["trainingEndDate"] as! String?)!)
            
            emergencycontacts.text = "Training end date : \(trainingEndDate!)"
            email1.text = "\((personDic["email"] as! [String])[0])"
            email2.text = "\((personDic["email"] as! [String])[1])"
            phone1.text = "\((personDic["phones"] as! [String:Any])["mobile"]!)"
            phone2.text = "\((personDic["phones"] as! [String:Any])["home"]!)"
            
            

        }catch{
            print("error in parsing")
        }
        
    }
    
}
