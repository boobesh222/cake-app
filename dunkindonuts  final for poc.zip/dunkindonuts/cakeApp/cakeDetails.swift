//
//  cakeDetails.swift
//  cakeApp
//
//  Created by IPhone Dev on 06/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation


class CakeVarietiesAndDetails {
    
    var id:Int
    var type:String
    var name:String
    var ppu:Double
    var Amount:Float
    var topping:[CakeToppings]
    var batters:[CakeBatters]
    var fillings:[CakeFilling]?
    
    
    
    init(id:Int,type:String,name:String,ppu:Double,Amount:Float,topping:[CakeToppings],batters:[CakeBatters]) {
        self.id = id
        self.type = type
        self.name = name
        self.ppu = ppu
        self.Amount = Amount
        self.topping = topping
        self.batters = batters
    }
    
    convenience init(id:Int,type:String,name:String,ppu:Double,Amount:Float,topping:[CakeToppings],batters:[CakeBatters],fillings:[CakeFilling]){
        self.init(id: id, type: type, name: name, ppu: ppu, Amount: Amount, topping: topping, batters: batters)
        self.fillings = fillings
    }
    
    
}

struct CakeToppings {
    var toppingsType:String
    var toppingsid:Int
}


struct CakeBatters {
    var battersType:String
    var battersId:Int
}

struct CakeFilling {
    var fillingsType:String
    var fillingsId:Int
}


struct PersonDetails {
    var personEmergencyDetails:EmergencyContacts
    var registered:Bool
    var dateOfBirth:Date
    var email:[String]
    var personPhoneNumbers:PhoneNumber
    var name:String
    var empID:String
}

struct EmergencyContacts {
    var relationShip:String
    var phone:Int
    var name:String
}

struct PhoneNumber {
    var home:Int
    var mobile:Int
}
