//
//  SplashScreenViewController.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 09/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import UIKit

class SplashScreenViewController:UIViewController{
     //"http://beta.json-generator.com/api/json/get/Nk3q17Xhz"
    /* collection of outlets from splashScreen StoryBoard */
    @IBOutlet weak var splashScreenActivityIndicator: UIActivityIndicatorView!
    
    
    var jsonData:NSData?
    typealias completionHandler = ()->Void
    
    let cakeMenuUrlLink = "http://www.json-generator.com/api/json/get/cfeLZCfKhu"
    var jsonHelperObject:JsonHelper?
   // http://www.json-generator.com/api/json/get/cfeLZCfKhu
    
    override func viewDidLoad() {
        splashScreenActivityIndicator.startAnimating()
         let jsonObject=JsonHelper(links:cakeMenuUrlLink)
         jsonHelperObject = jsonObject
        jsonObject.fetchCakeMenus(urlLinks: cakeMenuUrlLink){
                (data) in
                //jsonObject.getDetailedMenuList(jsonData: data)
            
            self.jsonData = data
            self.pushViewToOtherMenuViewController(jsonData: data)
            
        }
    }
    
    func pushViewToOtherMenuViewController(jsonData:NSData){
        print(jsonData.length)
        if (jsonHelperObject?.getDetailedMenuList(jsonData: jsonData))!{
            print("data fetched ")
            DispatchQueue.main.async {
                print("animation stopped ")
                self.splashScreenActivityIndicator.stopAnimating()
            }
            
            performSegue(withIdentifier: "ShowMenuSeque", sender:self)
            print("seque performed ")
        }else {
          print("data not fetched ")
          
        }
        
    }
    
    
    
}
