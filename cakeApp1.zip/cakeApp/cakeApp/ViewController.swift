//
//  ViewController.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 05/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
        
    let cakeMenuUrlLink = "http://beta.json-generator.com/api/json/get/Nk3q17Xhz"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        JsonHelper(links:cakeMenuUrlLink)
        var cakes = JsonHelper.cakeModel
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
}

