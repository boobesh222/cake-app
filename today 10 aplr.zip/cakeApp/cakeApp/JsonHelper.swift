//
//  JsonHelper.swift
//  cakeApp
//
//  Created by IPhone Dev on 06/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation

class JsonHelper{
    let webServiceUrlLinks:String
    static var cakeModel:[CakeVarietiesAndDetails] = []
    typealias completionHandler = (_:NSData)->Void
    var splashObj = SplashScreenViewController()
    init(links:String){
        webServiceUrlLinks = links
//        fetchCakeMenus(urlLinks: links){
//            print("data obtained successfully .......")
//        }
    }
    
    /* fetches json from the url */
    func fetchCakeMenus(urlLinks:String,completionH:@escaping completionHandler){
         URLSession.shared.dataTask(with: URL(string:urlLinks)! ){
            (data,response,error) in
            
            if (data?.count != nil ){
                completionH(data! as NSData)
            }
            //self.getDetailedMenuList(jsonData: data! as NSData, response: response as! HTTPURLResponse){
                
            //}
            
            }.resume()
        
        
        

    }
    
    
    /* traverse json data and get key value pairs  */
    func getDetailedMenuList(jsonData data:NSData){
        do {
            let jsonRootObjectDetails = try JSONSerialization.jsonObject(with: data as Data, options: [])
            let jsonDictionary = jsonRootObjectDetails as! [String:Any]
            let cakeMenuDictionary = jsonDictionary["items"] as! [String:Any]
            let  individualCakeObjects = cakeMenuDictionary["item"] as! [Any]
            JsonHelper.cakeModel.removeAll()
            for details in individualCakeObjects{
                print(details)
                var cakeDictionary = details as! [String:Any]
                if cakeDictionary["filling"] == nil{
                    print("framing cake model ")
                    JsonHelper.cakeModel.append( CakeVarietiesAndDetails(id: cakeDictionary["id"] as! Int, type: cakeDictionary["type"] as! String, name: cakeDictionary["name"] as! String, ppu: cakeDictionary["ppu"] as! Double, Amount: cakeDictionary["amount"] as! Float, topping: getToppingDetails(jsonObjectDetails: cakeDictionary), batters:getBatterDetails(jsonObjectDetails: cakeDictionary) ) )
                }else{
                     print("framing cake model for filling type")
                    JsonHelper.cakeModel.append( CakeVarietiesAndDetails(id: cakeDictionary["id"] as! Int, type: cakeDictionary["type"] as! String, name: cakeDictionary["name"] as! String, ppu: cakeDictionary["ppu"] as! Double, Amount: cakeDictionary["amount"] as! Float, topping: getToppingDetails(jsonObjectDetails: cakeDictionary), batters:getBatterDetails(jsonObjectDetails: cakeDictionary),fillings:getFillingDetails(jsonObjectDetails: cakeDictionary) ) )
                    
                }
                
            }
            print("cake dictionary count\(JsonHelper.cakeModel.count)")
            
        }catch{
            print("error in parsing the JSON object")
        }
        
    }
    
    
    /* func returns all the availabe topping for the donut */
    func getToppingDetails(jsonObjectDetails:[String:Any])->[CakeToppings]{
        var allToppingForCake:[CakeToppings]=[]
        let toppingObject = jsonObjectDetails["topping"]
        let toppingArray = toppingObject as! [Any]
        for toppingdetails in toppingArray{
            var toppingDictionary = toppingdetails as![String:Any]
            
            allToppingForCake.append(CakeToppings(toppingsType: toppingDictionary["type"] as! String, toppingsid: toppingDictionary["id"] as! Int))
            
        }
        return allToppingForCake
    }
    
    
    /* func returns all the availabe batters for the donut */
    func getBatterDetails(jsonObjectDetails:[String:Any])->[CakeBatters]{
        var allBatterForCake:[CakeBatters]=[]
        let batterObject = jsonObjectDetails["batters"]
        let batterObjectOne = batterObject as! [String:Any]
        let batter = batterObjectOne["batter"]
        let AllBatterArray = batter as! [Any]
        
        for batterDetails in AllBatterArray{
            var batterDictionary = batterDetails as![String:Any]
            
            allBatterForCake.append(CakeBatters(battersType: batterDictionary["type"] as! String, battersId: batterDictionary["id"] as! Int))
        }
        return allBatterForCake
    }
    
    
    /* func returns all the availabe fillings for the donut */
    func getFillingDetails(jsonObjectDetails:[String:Any])->[CakeFilling]{
        var allFillingsForCake:[CakeFilling]=[]
        let fillingObject = jsonObjectDetails["topping"]
        let fillingArray = fillingObject as! [Any]
        for fillingdetails in fillingArray{
            var fillingDictionary = fillingdetails as![String:Any]
            
            allFillingsForCake.append(CakeFilling(fillingsType:fillingDictionary["type"] as! String,fillingsId:fillingDictionary["id"] as! Int))
            
        }
        return allFillingsForCake
        
    }
}
