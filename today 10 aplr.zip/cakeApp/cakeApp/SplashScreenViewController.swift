//
//  SplashScreenViewController.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 09/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import UIKit

class SplashScreenViewController:UIViewController{
 
    /* collection of outlets from splashScreen StoryBoard */
    @IBOutlet weak var splashScreenActivityIndicator: UIActivityIndicatorView!
    
    typealias completionHandler = ()->Void
    let cakeMenuUrlLink = "http://beta.json-generator.com/api/json/get/Nk3q17Xhz"
    var jsonObject:JsonHelper?
    
    
    override func viewDidLoad() {
        splashScreenActivityIndicator.startAnimating()
         let jsonObject=JsonHelper(links:cakeMenuUrlLink)
        jsonObject.fetchCakeMenus(urlLinks: cakeMenuUrlLink){
                (data) in
                //jsonObject.getDetailedMenuList(jsonData: data)
            
            
            self.pushViewToOtherMenuViewController()
            
        }
    }
    
    func pushViewToOtherMenuViewController(){
        
        DispatchQueue.main.async {
            self.splashScreenActivityIndicator.stopAnimating()
            
        }
        
    }
    
    
    
}
