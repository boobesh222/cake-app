//
//  ViewController.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 05/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    let tableViewSectionsCount = 1
    var cakeModel:[CakeVarietiesAndDetails]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        cakeModel = JsonHelper.cakeModel
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /* donut  Table view datasource and delegates methods */
    
    func numberOfSections(in tableView: UITableView) -> Int {
        print("number iof sections ")
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("number of rows in sections ")
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cell for row at index path ")
        let cell = tableView.dequeueReusableCell(withIdentifier: "donutTableViewCellIdentifier", for: indexPath) as! CustomDonutcells
        cell.donutName.text = "popular Donut"
        cell.donutprice.text = "$ 78"
        
        return cell
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("table cell is selected  \(indexPath)")
    }
    
    
    
    
    
}

