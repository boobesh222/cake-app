//
//  CustomDonutCells.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 08/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import UIKit

class CustomDonutcells:UITableViewCell{

    
    @IBOutlet weak var donutImage: UIImageView!
    
    @IBOutlet weak var donutName: UILabel!
    
    @IBOutlet weak var donutprice: UILabel!
}
