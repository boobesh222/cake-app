//
//  contactDetails.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 11/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import UIKit

class ContactDetails:UIViewController{
    
    
    @IBOutlet weak var name: UILabel!
    
    
    @IBOutlet weak var empId: UILabel!
    
    @IBOutlet weak var dob: UILabel!
    
    @IBOutlet weak var registered: UILabel!
   
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var emergencycontacts: UILabel!
    
    
    override func viewDidLoad() {
        print("func overided")
        fetchContacts(data: JsonHelper.jsonData!)
    }

    func fetchContacts(data:NSData){
        do{
            
            let jsonRootObjectDetails = try JSONSerialization.jsonObject(with: data as Data, options: [])
            let jsonDictionary = jsonRootObjectDetails as! [String:Any]
           
            
            let  personDic = jsonDictionary["person"] as! [String:Any]
             name.text = ((personDic["name"] as! String?)!)
            empId.text="\((personDic["id"])!)"
            dob.text = "\((personDic["dateOfBirth"] as! String?)!)"
            registered.text = "\((personDic["registered"])!)"
            phone.text = "\((personDic["phones"] as! [String:Any]).count)  Phone numbers Found"
            email.text = "\((personDic["email"] as! [String]).count) emails Found"
            emergencycontacts.text = "\((personDic["emergencyContacts"] as! [Any]).count) emergency contacts"
        }catch{
            print("error in parsing")
        }
        
    }
    
}
