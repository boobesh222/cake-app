//
//  orderSummaryViewController.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 10/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import UIKit

class OrderSummaryViewController:UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UIGestureRecognizerDelegate{

    static var selectedRow:Int?
    var value = selectedRow!
    var cakeModel = JsonHelper.cakeModel
    
    var DonutDetails = DonutDetailsViewController()
    static var toppingArray:[String]?
    static var battersArray:[String]?
    static var fillingsArray:[String]?

    var topping = toppingArray!
   var batters = battersArray!
    var fillings = battersArray!

    let labelNamesArray = ["toppings","batters","fillings"]
    var labelsArray = Array<Array<String>>()
    
    
    
    
    
    @IBOutlet weak var cakeNameLabel: UILabel!
  
    
    @IBAction func stepperAction(_ sender: UIStepper) {
    quantityLabel.text = Int(sender.value).description
      
    }
    
   
    @IBOutlet weak var fillingsLabel: UILabel!
    @IBOutlet weak var batterLabel: UILabel!
    @IBOutlet weak var toppingLabel: UILabel!
    @IBOutlet weak var stepper: UIStepper!
    
    @IBOutlet weak var quantityLabel: UILabel!
    
    @IBAction func payAmountButton(_ sender: Any) {
        let alertController = UIAlertController(title: "Order Placed Sucessfully", message:
            "Thank you ,Payment Received", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
        
        print("Alert presented ")
    }
    
    
    @IBAction func showContactDetails(_ sender: Any) {
        
    }
    
    override func viewDidLoad() {
        print(value)
        
        labelsArray.append(topping)
        labelsArray.append(batters)
        labelsArray.append(fillings)
        
        stepper.autorepeat = true
        stepper.maximumValue = 10
        
        populateUI()
    }
    
    func populateUI(){
        cakeNameLabel.layer.masksToBounds = true
         cakeNameLabel.layer.cornerRadius = 10
        cakeNameLabel.text = cakeModel[value].name
        
        
        fillingsLabel.addGestureRecognizer(gestureProvider())
       
       batterLabel.addGestureRecognizer(gestureProvider())
        toppingLabel.addGestureRecognizer(gestureProvider())
        
    }
    
    func gestureProvider()->UITapGestureRecognizer{
        print("gesture provided to all labels ")
        let tapGesture = UITapGestureRecognizer(target: self, action:#selector(labelTapGestureHandler(sender:)))
        tapGesture.delegate = self
        tapGesture.numberOfTouchesRequired = 1
        tapGesture.numberOfTapsRequired = 1
        return tapGesture
        
    }
    
    func labelTapGestureHandler(sender:UITapGestureRecognizer){
        print("labelTapGestureHandler")
        generatePicker(pickerTags: sender.view!.tag)
    }
    
    func generatePicker(pickerTags:Int) {
        print("generate picker")
        let vc = UIViewController()
        vc.preferredContentSize = CGSize(width: 250,height: 300)
        let pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: 250, height: 300))
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.tag = pickerTags
        vc.view.addSubview(pickerView)
        let pickerAlert = UIAlertController(title: "choose the options)", message: "", preferredStyle: UIAlertControllerStyle.alert)
        pickerAlert.setValue(vc, forKey: "contentViewController")
        pickerAlert.addAction(UIAlertAction(title: "Done", style: .default, handler: nil))
        pickerAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(pickerAlert, animated: true)
    }
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return givePickerCount(forPickerView:pickerView)
    }
    
    func givePickerCount(forPickerView:UIPickerView)->Int{
        switch forPickerView.tag {
        case 0:
            return topping.count
        case 1:
            return batters.count
        case 2:
            return fillings.count
        
        default:
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        let titleArray = labelsArray[pickerView.tag]
        return titleArray[row]
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let titleArray = labelsArray[pickerView.tag]
        print(labelsArray[pickerView.tag][row])
        print(titleArray[row])
        updateFormFieldData(selectedPickerView: pickerView, selectedrow: row)
    }
    
    func updateFormFieldData(selectedPickerView pickerView:UIPickerView , selectedrow row:Int){
        identifyLabel(selectedPickerView: pickerView).text = labelsArray[pickerView.tag][row]
        
        print("key is \(labelNamesArray[pickerView.tag]) and the value is \(labelsArray[pickerView.tag][row])")
        
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 36.0
    }
    
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 200
    }
    
    func identifyLabel(selectedPickerView pickerView:UIPickerView) -> UILabel{
        switch pickerView.tag {
       
        case 0:
            return toppingLabel
        case 1:
            return batterLabel
        case 2:
            return fillingsLabel
        
        default:
            return toppingLabel
        }
        
    }

   
    
}

