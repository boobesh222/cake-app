//
//  DonutDetailsViewController.swift
//  cakeApp
//
//  Created by IPhone Dev on 10/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import UIKit

class DonutDetailsViewController:UIViewController{
    static var value:Int?
    var selectedrow:Int? = value!
    var cakeList = JsonHelper.cakeModel
     var toppingsArray:[String]?
    var battersArray:[String]?
    var fillingsArray:[String]?
    var donutImages = ["donutAppleFritter","donutCake","donutFilled","donutOldFashioned","donutRaised"]
    var obj = ViewController()
   
    @IBOutlet weak var donutImage: UIImageView!
    @IBOutlet weak var toppings: UILabel!
 
    @IBOutlet weak var batters: UILabel!

    @IBOutlet weak var fillings: UILabel!
    
    @IBOutlet weak var amount: UILabel!
    
    @IBOutlet weak var cakeName: UILabel!
    
    @IBAction func placeOrder(_ sender: Any) {
        
      
    }
    
    
    init(){
    super.init(nibName: nil, bundle: nil)
        print("1 inits")
        //cakeName.backgroundColor = UIColor(red: 255, green: 255, blue: 255, alpha: 255 )
        
    }
    
     convenience init(row:Int) {
       
      self.init()
        selectedrow = row
        print("selected row is \(selectedrow!)")
        print("second initi")
        
       
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
    }
    
    
    override func viewDidLoad() {
    print("view did load ")
        cakeName.layer.masksToBounds = true
        cakeName.layer.cornerRadius = 10

        populateDonutDetails()
    }
    
    func populateDonutDetails(){
       
       cakeName.text = cakeList[selectedrow!].name
      donutImage.image = UIImage(named: (obj.donutImages[selectedrow!]))
       toppings.text = "Available Toppings : \(gettoppings())"
        batters.text = "Available Batters : \(getBatters())"
        fillings.text = "Available Fillings : \(getFillings())"
        amount.text = " RS : \(cakeList[selectedrow!].Amount) "
    }
   
    func gettoppings()->String{
        var availabelToppingsStrings = String()
        
        for toppingDetails in cakeList[selectedrow!].topping{
             toppingsArray?.append(toppingDetails.toppingsType)
            availabelToppingsStrings.append(",")
            availabelToppingsStrings.append(toppingDetails.toppingsType)
        }
        print(availabelToppingsStrings)
        return availabelToppingsStrings
    }
    
    func getBatters()->String{
        var availableBattersString = String()
        for battersDetails in cakeList[selectedrow!].batters{
             battersArray?.append(battersDetails.battersType)
            availableBattersString.append(",")
            availableBattersString.append(battersDetails.battersType)
        }
        print(availableBattersString)
    return availableBattersString
    }
    
    
    func getFillings()->String{
        var availableFillingsString = String()
        if let fillings = cakeList[selectedrow!].fillings{
            for fillingsDetails in fillings{
                fillingsArray?.append(fillingsDetails.fillingsType)
                availableFillingsString.append(",")
                availableFillingsString.append(fillingsDetails.fillingsType)
            
            }
            print(availableFillingsString)
         return availableFillingsString
        }else {
           return "No fillings Availabel"
        }
    
    }
    
}
