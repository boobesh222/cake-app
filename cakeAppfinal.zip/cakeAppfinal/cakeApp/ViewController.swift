//
//  ViewController.swift
//  cakeApp
//
//  Created by Boobesh Balasubramanian on 05/04/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    let tableViewSectionsCount = 1
    var cakeModel = JsonHelper.cakeModel
     var row:Int?
    //var jsonHelperObject = JsonHelper()
    //var donutDetailsObject =  DonutDetailsViewController()
    var donutImages = ["donutAppleFritter","donutCake","donutFilled","donutOldFashioned","donutRaised"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        cakeModel = JsonHelper.cakeModel
       
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /* donut  Table view datasource and delegates methods */
    
    func numberOfSections(in tableView: UITableView) -> Int {
        print("number iof sections ")
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("number of rows in sections ")
        return cakeModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cell for row at index path ")
        let cell = tableView.dequeueReusableCell(withIdentifier: "donutTableViewCellIdentifier", for: indexPath) as! CustomDonutcells
        
        cell.donutImage.image = UIImage(named: donutImages[indexPath.row])
        cell.donutName.text = cakeModel[indexPath.row].name
        cell.donutprice.text = "Rs \(String(describing: cakeModel[indexPath.row].Amount))"
        cell.layer.cornerRadius =  20
        cell.donutName.layer.masksToBounds = true
        cell.donutprice.layer.masksToBounds = true

        cell.donutName.layer.cornerRadius = 5
        cell.donutprice.layer.cornerRadius = 5
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        row = indexPath.row
        DonutDetailsViewController.value = indexPath.row
        //DonutDetailsViewController(row:indexPath.row)
        
        performSegue(withIdentifier: "foo", sender:self)
    }
    
    
    
    
    
}

